package Email::ESP::ExactTarget::Subscriber;

use warnings;
use strict;

use Carp;
use Data::Dumper;
use URI::Escape;


=head1 NAME

Email::ESP::ExactTarget::Subscriber

=head1 VERSION

Version 1.1.1

=cut

our $VERSION = '1.1.1';


=head1 SYNOPSIS

	# Create a new subscriber object.
	my $subscriber = Email::ESP::ExactTarget::Subscriber->new();

	# Set attributes.
	$subscriber->set(
		'First Name' => 'John',
		'Last Name'  => 'Doe',
	);

	# Get attributes.
	my $first_name = $subscriber->get('First Name');
	my $attributes = $subscriber->get();

	# ExactTarget's subscriber ID, if applicable.
	my $subscriber_id = $subscriber->id();

=head1 METHODS


=head2 new()

Creates a new Subscriber object.

	my $subscriber = Email::ESP::ExactTarget::Subscriber->new();

=cut

sub new
{
	my ( $class, %args ) = @_;

	# Create the object.
	my $self = bless(
		{
			'attributes'        => {},
			'staged_attributes' => {},
			'lists'             => {},
			'staged_lists'      => {},
		},
		$class
	);

	return $self;
}


=head2 set()

Sets the attributes and values for the current subscriber object.

	$subscriber->set(
		'Email Address' => $email,
		'First Name'    => $first_name,
	);

Note that it does not interact with Exact Target - it only alters the object.

=cut

sub set
{
	my ( $self, %args ) = @_;

	foreach my $key ( keys %args )
	{
		$self->{'attributes'}->{$key} = $args{$key};
	}
}


=head2 get()

When passed an attribute name as a parameter, retrieves the corresponding value:

	my $email = $subscriber->get('Email Address');

Alternatively, if no attribute name is passed, returns a hashref of all the
attributes / values pairs.

	my $values = $subscriber->get();

	print $values->{'Email Address'};

=cut

sub get
{
	my ( $self, $attribute ) = @_;

	if ( defined( $attribute ) )
	{
		return $self->{'attributes'}->{$attribute};
	}
	else
	{
		return { %{ $self->{'attributes'} || {} } };
	}
}


=head2 id()

Returns the Subscriber ID associated to the current Subscriber in Exact Target's
database.

	$subscriber->id( 123456789 );

	my $subscriber_id = $subscriber->id();

This will return undef if the object hasn't loaded the subscriber information
from the database, or if a new subscriber hasn't been committed to the database.

=cut

sub id
{
	my ( $self, $id ) = @_;
	
	if ( defined( $id ) )
	{
		die 'Subscriber ID format is incorrect'
			unless $id =~ m/^\d+$/;
		
		$self->{'id'} = $id;
	}
	
	return $self->{'id'};
}


=head2 staged_set()

Stores the attributes and values that will be inserted or updated later in
ExactTarget's database.

	$subscriber->staged_set(
		'Email Address' => $email,
		'First Name'    => $first_name,
	);

=cut

sub staged_set
{
	my ( $self, %args ) = @_;
	
	foreach my $key ( keys %args )
	{
		$self->{'staged_attributes'}->{$key} = $args{$key};
	}
}


=head2 staged_get()

When passed an attribute name as a parameter, retrieves the corresponding staged
value to be applied to the remote ExactTarget database.

	my $email = $subscriber->staged_get('Email Address');

Alternatively, if no attribute name is passed, returns a hashref of all the
attributes / values pairs to be applied to the remote ExactTarget database.

	my $values = $subscriber->staged_get();
	
	print $values->{'Email Address'};

=cut

sub staged_get
{
	my ( $self, $attribute ) = @_;
	
	if ( defined( $attribute ) )
	{
		return $self->{'staged_attributes'}->{$attribute};
	}
	else
	{
		return { %{ $self->{'staged_attributes'} || {} } };
	}
}


=head2 apply_staged_attributes()

Moves the staged attribute changes onto the current object, effectively
'applying' the changes.

	$subscriber->apply_staged_attributes(
		'Email Address',
		'First Name',
	);

=cut

sub apply_staged_attributes
{
	my ( $self, @field ) = @_;
	
	foreach my $field ( @field )
	{
		$self->set( $field => $self->{'staged_attributes'}->{$field} );
		delete( $self->{'staged_attributes'}->{$field} );
	}
}


=head2 staged_set_lists_status()

Stores the list IDs and corresponding subscription status locally. This has no
influence on ExactTarget's data.

	$subscriber->set_lists_status(
		'1234567' => 'Active',
		'1234568' => 'Unsubscribed',
	);

'Active' and 'Unsubscribed' are the two valid status for list subscriptions.

=cut

sub set_lists_status
{
	my ( $self, %status ) = @_;
	
	foreach my $list_id ( keys %status )
	{
		$self->{'lists'}->{ $list_id } = $status{$list_id};
	}
}


=head2 staged_set_lists_status()

Returns the local subscription status for the lists on the current object.

	my %lists_status = $subscriber->get_lists_status();

=cut

sub get_lists_status
{
	my ( $self ) = @_;
	
	return %{ $self->{'lists'} || {} };
}


=head2 staged_set_lists_status()

Stores the list IDs and corresponding subscription status to be updated in
ExactTarget when an 'update' action is performed on the current object.

	$subscriber->staged_set_lists_status(
		'1234567' => 'Active',
		'1234568' => 'Unsubscribed',
	);

'Active' and 'Unsubscribed' are the two valid status for list subscriptions.

=cut

sub staged_set_lists_status
{
	my ( $self, %status ) = @_;
	
	foreach my $list_id ( keys %status )
	{
		my $status = $status{$list_id};
		
		die "The status for list ID >$list_id< must be defined"
			unless defined( $status );
		
		die "The status >$status< for list ID >$list_id< is incorrect"
			unless $status =~ m/^(Active|Unsubscribed)$/;
		
		$self->{'staged_lists'}->{$list_id} = $status
	}
}


=head2 staged_get_lists_status()

Retrieves the hash of staged list status changes to be applied to the remote
ExactTarget database.

	my %change = $subscriber->staged_get_lists_status();

=cut

sub staged_get_lists_status
{
	my ( $self ) = @_;
	
	return %{ $self->{'staged_lists'} || {} };
}


=head2 apply_staged_lists_status()

Moves the staged list subscription changes onto the current object, effectively
'applying' the changes.

	my %change = $subscriber->apply_staged_lists_status(
		'1234567' => 'Active',
		'1234568' => 'Unsubscribed',
	);

=cut

sub apply_staged_lists_status
{
	my ( $self, %status ) = @_;
	
	foreach my $list_id ( keys %status )
	{
		delete( $self->{'staged_lists'}->{$list_id} );
		$self->{'lists'}->{ $list_id } = $status{$list_id};
	}
}


=head2 add_error()

Adds a new error message to the current object.

	$subscriber->add_error( 'Cannot update object.' );

=cut

sub add_error
{
	my ( $self, $error ) = @_;
	
	return
		unless defined( $error ) && ( $error ne '' );
	
	$self->{'errors'} ||= [];
	push( @{ $self->{'errors'} }, $error );
}


=head2 errors()

Returns the errors stored on the current object as an arrayref if there is any,
otherwise returns undef.

	my $errors = $subscriber->errors();
	if ( defined( $errors ) )
	{
		print Dumper( $errors );
	}

=cut

sub errors
{
	my ( $self ) = @_;
	
	return $self->{'errors'};
}


=head1 AUTHOR

Guillaume Aubert, C<< <guillaumeaubert at users.sourceforge.net> >>.


=head1 BUGS

Please report any bugs or feature requests to C<bug-email-esp-exacttarget at rt.cpan.org>, or through
the web interface at L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=Email-ESP-ExactTarget>.  I will be notified, and then you'll
automatically be notified of progress on your bug as I make changes.


=head1 SUPPORT

You can find documentation for this module with the perldoc command.

	perldoc Email::ESP::ExactTarget::Subscriber


You can also look for information at:

=over 4

=item * RT: CPAN's request tracker

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=Email-ESP-ExactTarget>

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/Email-ESP-ExactTarget>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/Email-ESP-ExactTarget>

=item * Search CPAN

L<http://search.cpan.org/dist/Email-ESP-ExactTarget/>

=back


=head1 ACKNOWLEDGEMENTS

Thanks to Geeknet, Inc. L<http://www.geek.net> for funding the initial development of this code!


=head1 COPYRIGHT & LICENSE

Copyright 2009-2011 Guillaume Aubert.

This program is free software; you can redistribute it and/or modify it
under the terms of the Artistic License.

See http://dev.perl.org/licenses/ for more information.

=cut

1;
