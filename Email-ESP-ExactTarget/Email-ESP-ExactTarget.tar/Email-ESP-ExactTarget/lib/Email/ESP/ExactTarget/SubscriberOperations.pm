package Email::ESP::ExactTarget::SubscriberOperations;

use warnings;
use strict;

use Carp;
use Data::Dumper;
use URI::Escape;
use Text::Unaccent qw();

use Email::ESP::ExactTarget::Subscriber;

=head1 NAME

Email::ESP::ExactTarget::SubscriberOperations

=head1 VERSION

Version 1.1.1

=cut

our $VERSION = '1.1.1';


=head1 SYNOPSIS

	# Create a new subscriber operations object
	my $subscriber_operations = $exact_target->subscriber_operations();
	
	my $subscribers;
	eval
	{
		$subscribers = $subscriber_operations->retrieve(
			'email' => [ qw( test@test.invalid foo@bar.invalid ) ],
		);
	};


=head1 METHODS

=head2 new()

Creates a new SubscriberOperations object, requires an Email::ESP::ExactTarget
object to be passed as parameter.

	my $subscriber_operations = Email::ESP::ExactTarget::SubscriberOperations->new( $exact_target );

Note that this is not the recommended way of creating a SubscriberOperations
object. If you are writing a script using this distribution, you should use
instead:

	my $subscriber_operations = $exact_target->subscriber_operations();

=cut

sub new
{
	my ( $class, $exact_target, %args ) = @_;

	# Require an Email::ESP::ExactTarget object to be passed
	die 'Pass an Email::ESP::ExactTarget object to create an Email::ESP::ExactTarget::SubscriberOperations object'
		unless defined( $exact_target ) $exact_target->isa( 'Email::ESP::ExactTarget' );
	
	# Create the object
	my $self = bless(
		{
			'exact_target' => $exact_target,
		},
		$class
	);
	
	return $self;
}


=head2 esp()

Returns the main Exact Target object.

	$exact_target = $subscriber_operations->esp();

=cut

sub esp
{
	my $self = shift;

	return $self->{'exact_target'};
}


=head2 create()

Creates a new subscriber in ExactTarget's database using the staged changes on
the subscriber objects passed as parameter.

	$subscriber_operations->create(
		@subscriber
	);

=cut

sub create
{
	my ( $self, @subscriber ) = @_;

	return $self->_update_create(
		'subscribers' => \@subscriber,
		'soap_action' => 'Create',
		'soap_method' => 'CreateRequest',
		'options'     => undef,
	);
}


=head2 update_or_create()

Creates a new subscriber in ExactTarget's database using the staged changes on
the subscriber objects passed as parameter. If the subscriber already exists in
the database, updates it.

	$subscriber_operations->update_or_create(
		@subscriber
	);

=cut

sub update_or_create
{
	my ( $self, @subscriber ) = @_;

	return $self->_update_create(
		'subscribers' => \@subscriber,
		'soap_action' => 'Create',
		'soap_method' => 'CreateRequest',
		'options'     => SOAP::Data->name(
			'Options' => \SOAP::Data->value(
				SOAP::Data->name(
					'SaveOptions' => \SOAP::Data->value(
						SOAP::Data->name(
							'SaveOption' => \SOAP::Data->value(
								SOAP::Data->name(
									'PropertyName' => '*',
								),
								SOAP::Data->name(
									'SaveAction' => 'UpdateAdd',
								),
							),
						),
					),
				),
			),
		),
	);
}


=head2 update()

Applies to ExactTarget's database any staged changes on the subscriber objects
passed as parameter.

	$subscriber_operations->update(
		@subscriber
	);

=cut

sub update
{
	my ( $self, @subscriber ) = @_;

	return $self->_update_create(
		'subscribers' => \@subscriber,
		'soap_action' => 'Update',
		'soap_method' => 'UpdateRequest',
		'options'     => SOAP::Data->name(
			'Options' => \SOAP::Data->value(),
		),
	);
}


=head2 _update_create()

Internal. Updates or create a set of subscribers.

	$subscriber_operations->_update_create(
		'subscribers' => \@subscriber,
		'soap_action' => 'Update',
		'soap_method' => 'UpdateRequest',
	);

	$subscriber_operations->_update_create(
		'subscribers' => \@subscriber,
		'soap_action' => 'Create',
		'soap_method' => 'CreateRequest',
	);

=cut

sub _update_create
{
	my ( $self, %args ) = @_;
	my @subscriber = @{ $args{'subscribers'} || [] };

	# Shortcuts.
	my $exact_target = $self->esp() || die 'Email::ESP::ExactTarget object is not defined';
	my $verbose = $exact_target->verbose();
	
	# Check data.
	die 'No subscribers were passed to update.'
		unless scalar( @subscriber ) != 0;
	
	# Prepare SOAP content.
	my @soap_data = ();
	if ( defined( $args{'options'} ) )
	{
		push( @soap_data, $args{'options'} );
	}
	
	foreach my $subscriber ( @subscriber )
	{
		my @object = ();
		
		if ( $args{'soap_action'} eq 'Create' )
		{
			# Use the new email address as unique identifier.
			push(
				@object,
				SOAP::Data->name(
					'EmailAddress' => $subscriber->staged_get('Email Address'),
				),
			);
		}
		else
		{
			# Reuse the existing identifiers.
			push(
				@object,
				SOAP::Data->name(
					'EmailAddress' => $subscriber->get('Email Address'),
				),
				SOAP::Data->name(
					'ID' => $subscriber->id(),
				),
			);
		}
		
		# Add the new values for attributes and list subscriptions.
		push(
			@object,
			$self->soap_format_attributes( $subscriber->staged_get() ),
			$self->soap_format_lists(
				'current' => { $subscriber->get_lists_status() },
				'staged'  => { $subscriber->staged_get_lists_status() },
			),
		);
		
		# Create the new subscriber block in the SOAP message.
		push(
			@soap_data,
			SOAP::Data->name(
				'Objects' => \SOAP::Data->value(
					@object
				),
			)->attr( { 'xsi:type' => 'Subscriber' } ),
		)
	}
	
	my $soap_args =
	[
		SOAP::Data->value(
			@soap_data
		)
	];
	
	# Get Exact Target's reply.
	my $soap_response = $exact_target->soap_call(
		'action'    => $args{'soap_action'},
		'method'    => $args{'soap_method'},
		'arguments' => $soap_args,
	);
	
	my @soap_params_out  = $soap_response->paramsall();
	my $soap_success = pop( @soap_params_out );
	my $soap_request_id = pop( @soap_params_out );
	
	# Check for errors.
	die Dumper( $soap_response->fault() )
		if defined( $soap_response->fault() );
	
	die 'The SOAP status is not >OK< - ' . Dumper( $soap_response->paramsall() )
		unless defined( $soap_success ) && ( $soap_success eq 'OK' );
	
	# Check the detail of the response for each object, and update accordingly.
	my %update_details = ();
	foreach my $param_out ( @soap_params_out )
	{
		$update_details{ $param_out->{'Object'}->{'EmailAddress'} } = $param_out;
	}
	foreach my $subscriber ( @subscriber )
	{
		my $email = $args{'soap_action'} eq 'Create'
			? $subscriber->staged_get('Email Address')
			: $subscriber->get('Email Address');

		my $update_details = $update_details{ $email };

		# Check the individual status code to determine if the update for that
		# subscriber was successful.
		if ( $update_details->{'StatusCode'} ne 'OK' )
		{
			$subscriber->add_error( $update_details->{'StatusMessage'} );
			next;
		}
		
		# Set the ExactTarget ID on the current object.
		$subscriber->id( $update_details->{'Object'}->{'ID'} );
		
		# Apply the staged attributes that ExactTarget reports as updated.
		if ( defined ( $update_details->{'Object'}->{'Attributes'} ) )
		{
			my $attributes;
			if ( ref( $update_details->{'Object'}->{'Attributes'} ) eq 'ARRAY' )
			{
				$attributes = $update_details->{'Object'}->{'Attributes'};
			}
			else
			{
				$attributes = [ $update_details->{'Object'}->{'Attributes'} ];
			}
			$subscriber->apply_staged_attributes(
				map { $_->{'Name'} } @$attributes
			);
		}
		
		# Apply the staged list status updates.
		if ( defined ( $update_details->{'Object'}->{'Lists'} ) )
		{
			my $lists;
			if ( ref( $update_details->{'Object'}->{'Lists'} ) eq 'ARRAY' )
			{
				$lists = $update_details->{'Object'}->{'Lists'};
			}
			else
			{
				$lists = [ $update_details->{'Object'}->{'Lists'} ];
			}

			$subscriber->apply_staged_lists_status(
				map
				{
					$_->{'ID'} => $_->{'Status'}
				} @$lists
			);
		}
		
		# Make sure that all the staged updates have been performed by ExactTarget.
		my $attributes_remaining = $subscriber->staged_get();
		if ( scalar( keys %$attributes_remaining ) )
		{
			$subscriber->add_error('The following staged changes were not applied: ' . join(', ', keys %$attributes_remaining ) . '.' );
		}
		my %lists_remaining = $subscriber->staged_get_lists_status();
		if ( scalar( keys %lists_remaining ) )
		{
			$subscriber->add_error(
				"The following staged lists status changes were not applied:\n"
				. join( "\n", map { "   $_ => $lists_remaining{$_}" } keys %lists_remaining )
			);
		}
	}
	
	return undef;
}


=head2 retrieve()

Retrieves from ExactTarget's database the subscribers corresponding to the
unique identifiers passed as parameter.

	my @subscriber = $subscriber_operations->retrieve(
		'email' => [ $email1, $email2 ],
	);

=cut

sub retrieve
{
	my ( $self, %args ) = @_;

	# Check parameters
	die 'Emails identifying the subscribers to retrieve were not passed.'
		unless defined( $args{'email'} );
	
	die "The 'email' parameter must be an arrayref"
		unless  ref( $args{'email'} ) eq 'ARRAY';
	
	die 'Emails identifying the subscribers to retrieve were not passed.'
		unless scalar( @{ $args{'email'} } );
	
	# Shortcuts.
	my $exact_target = $self->esp() || die 'Email::ESP::ExactTarget object is not defined';
	my $verbose = $exact_target->verbose();

	# Prepare SOAP content
	my $soap_args =
	[
		SOAP::Data->name(
			RetrieveRequest => \SOAP::Data->value(
				SOAP::Data->name(
					ObjectType => 'Subscriber',
				),
				SOAP::Data->name(
					Properties => 'ID',
				),
				SOAP::Data->name(
					'Filter' => \SOAP::Data->value(
						SOAP::Data->name(
							Property => 'EmailAddress',
						),
						SOAP::Data->name(
							SimpleOperator => 'IN',
						),
						SOAP::Data->name(
							Value => @{ $args{'email'} },
						),
					),
				)->attr( { 'xsi:type' => 'SimpleFilterPart' } ),
			),
		),
	];
	
	# Get Exact Target's reply.
	my $soap_response = $exact_target->soap_call(
		'action'    => 'Retrieve',
		'method'    => 'RetrieveRequestMsg',
		'arguments' => $soap_args,
	);
	my ( $soap_success, $soap_request_id, @soap_object ) = $soap_response->paramsall();
	
	# Check for errors.
	die Dumper( $soap_response->fault() )
		if defined( $soap_response->fault() );
	
	die "The SOAP status is not 'OK'."
		unless defined( $soap_success ) && ( $soap_success eq 'OK' );
	
	die "No objects returned."
		unless scalar( @soap_object ) != 0;
	
	# Turn the SOAP objects into known objects.
	my @subscriber = ();
	foreach my $soap_object ( @soap_object )
	{
		# Check for errors in the XML returned.
		die "No attributes found."
			unless defined( $soap_object->{'Attributes'} );
		
		die 'No subscriber ID found.'
			unless defined( $soap_object->{'ID'} );
		
		# Create a Subscriber object and fill it.
		my $subscriber = Email::ESP::ExactTarget::Subscriber->new();
		$subscriber->id( $soap_object->{'ID'} );
		$subscriber->set(
			map
			{
				$_->{'Name'} => $_->{'Value'}
			} @{ $soap_object->{'Attributes'} }
		);
		
		push( @subscriber, $subscriber );
	}
	
	return \@subscriber;
}


=head2 pull_list_subscriptions()

Pulls from ExactTarget's database the list subscriptions for the subscribers
passed as parameter.

	$subscriber_operations->pull_list_subscriptions(
		@subscriber
	);

=cut

sub pull_list_subscriptions
{
	my ( $self, @subscriber ) = @_;
	
	# Shortcuts.
	my $exact_target = $self->esp() || die 'Email::ESP::ExactTarget object is not defined';
	my $verbose = $exact_target->verbose();
	
	# Check data.
	die 'No subscribers were passed to update.'
		unless scalar( @subscriber ) != 0;
	
	# Prepare SOAP content
	my $soap_args = [
		SOAP::Data->name(
			RetrieveRequest => \SOAP::Data->value(
				SOAP::Data->name(
					ObjectType => 'ListSubscriber',
				),
				SOAP::Data->name(
					Properties => qw( ListID SubscriberKey Status ),
				),
				SOAP::Data->name(
					'Filter' => \SOAP::Data->value(
						SOAP::Data->name(
							Property => 'SubscriberKey',
						),
						SOAP::Data->name(
							SimpleOperator => 'IN',
						),
						SOAP::Data->name(
							# IN requires at least _two_ values to be passed or it will die.
							# Since the webservice deduplicates the values passed, just pass
							# the first object twice.
							Value => ( map { $_->get('Email Address') } ( @subscriber, $subscriber[0] ) ),
						),
					),
				)->attr( { 'xsi:type' => 'SimpleFilterPart' } ),
			),
		),
	];
	
	# Get Exact Target's reply.
	my $soap_response = $exact_target->soap_call(
		'action'    => 'Retrieve',
		'method'    => 'RetrieveRequestMsg',
		'arguments' => $soap_args,
	);
	
	my ( $soap_success, $soap_request_id, @soap_params_out ) = $soap_response->paramsall();
	
	# Check for errors.
	die Dumper( $soap_response->fault() )
		if defined( $soap_response->fault() );
	
	die "The SOAP status is not 'OK'"
		unless defined( $soap_success ) && ( $soap_success eq 'OK' );
	
	# Check the detail of the response for each object, and update accordingly.
	my %subscriber = map
	{
		$_->get('Email Address') => $_
	} @subscriber;
	
	foreach my $param_out ( @soap_params_out )
	{
		$subscriber{ $param_out->{'SubscriberKey'} }->set_lists_status( $param_out->{'ListID'} => $param_out->{'Status'} );
	}
	
	return undef;
}


=head2 soap_format_lists()

Formats the lists subscription changes passed as a hashref for inclusion in the
SOAP messages.

	my $soap_lists = $self->soap_format_lists( $lists );

See http://wiki.memberlandingpages.com/API_References/Web_Service_Guide/_Technical_Articles/Managing_Subscribers_On_Lists.

=cut

sub soap_format_lists
{
	my ( $self, %args ) = @_;
	
	my $status_current = $args{'current'};
	my $status_staged = $args{'staged'};
	
	die 'Current lists status not defined'
		unless defined( $status_current );
	
	die 'Staged lists status not defined'
		unless defined( $status_staged );
	
	my @lists = ();
	foreach my $list_id ( keys %$status_staged )
	{
		push(
			@lists,
			SOAP::Data->name(
				'Lists' => \SOAP::Data->value(
					SOAP::Data->name(
						'ID' => $list_id,
					),
					SOAP::Data->name(
						'Status' => $status_staged->{$list_id},
					),
					SOAP::Data->name(
						'Action' => defined( $status_current->{$list_id} )
							? 'update'
							: 'create',
					),
				),
			),
		);
	}

	return @lists;
}


=head2 soap_format_attributes()

Formats the attributes passed as a hashref for inclusion in the SOAP messages.

	my $soap_attributes = $self->soap_format_attributes( $attributes );

=cut

sub soap_format_attributes
{
	my ( $self, $attributes ) = @_;
	
	die 'Attributes not defined'
		unless defined( $attributes );
	
	if ( $self->esp()->unaccent() )
	{
		map
		{
			$attributes->{$_} = Text::Unaccent::unac_string( 'latin1', $attributes->{$_} )
		} keys %$attributes;
	}
	
	my @attribute = ();
	foreach my $name ( keys %{ $attributes } )
	{
		push(
			@attribute,
			SOAP::Data->name(
				'Attributes' => \SOAP::Data->value(
					SOAP::Data->name(
						'Name' => $name,
					),
					SOAP::Data->name(
						'Value' => $attributes->{$name},
					),
				),
			),
		);
	}
	
	return @attribute;
}


=head1 AUTHOR

Guillaume Aubert, C<< <guillaumeaubert at users.sourceforge.net> >>.


=head1 BUGS

Please report any bugs or feature requests to C<bug-email-esp-exacttarget at rt.cpan.org>, or through
the web interface at L<http://rt.cpan.org/NoAuth/ReportBug.html?Queue=Email-ESP-ExactTarget>.  I will be notified, and then you'll
automatically be notified of progress on your bug as I make changes.


=head1 SUPPORT

You can find documentation for this module with the perldoc command.

	perldoc Email::ESP::ExactTarget::SubscriberOperations


You can also look for information at:

=over 4

=item * RT: CPAN's request tracker

L<http://rt.cpan.org/NoAuth/Bugs.html?Dist=Email-ESP-ExactTarget>

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/Email-ESP-ExactTarget>

=item * CPAN Ratings

L<http://cpanratings.perl.org/d/Email-ESP-ExactTarget>

=item * Search CPAN

L<http://search.cpan.org/dist/Email-ESP-ExactTarget/>

=back


=head1 ACKNOWLEDGEMENTS

Thanks to Geeknet, Inc. L<http://www.geek.net> for funding the initial development of this code!


=head1 COPYRIGHT & LICENSE

Copyright 2009-2011 Guillaume Aubert.

This program is free software; you can redistribute it and/or modify it
under the terms of the Artistic License.

See http://dev.perl.org/licenses/ for more information.

=cut

1;
