package TestModule2;

our $VERSION = '1.2.4';

1;
