package TestModule1;

our $VERSION = '1.2.3';

1;
