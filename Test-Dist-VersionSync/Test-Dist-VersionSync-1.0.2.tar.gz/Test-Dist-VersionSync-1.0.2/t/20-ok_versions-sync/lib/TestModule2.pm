package TestModule2;

our $VERSION = '1.2.3';

1;
